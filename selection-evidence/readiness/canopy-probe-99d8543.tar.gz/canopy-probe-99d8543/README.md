# Canopy Relay upstream readiness probes

This source-bound probe executes product-relevant success and failure behavior at the exact selected upstream revisions. The recorder runs each mode separately and keeps the raw output.

| Upstream | Revision | Success operation | Failure assertion |
|---|---|---|---|
| ruvnet/RuCelium | `813da13eb9a46b6acf78fe7ecc8c220ecf83b386` | Verify and ingest a signed field sample | A forged packet cannot advance the replay window |
| ruvnet/worldgraph | `9b1c79c836cdacfb7b44f058c593157bac4c1dab` | Build semantic state with provenance | An edge with an unknown endpoint is rejected |
| ruvnet/midstream | `62c37c9e8d282a4249de41aaf63649230338f738` | Compare habitat time series with DTW | A sequence beyond the configured bound is rejected |
| ruvnet/LatentMesh | `df9270799a1391925c1840a1845a6d169aaa2d93` | Reassemble an out-of-order constrained-link message | A conflicting duplicate fragment is rejected |
| ruvnet/ruv-FANN | `f4ca36c2323d08eac822bac43b62040198721cbf` | Execute a deterministic neural forward pass | Wrong-dimensional input is rejected |
| cedar-policy/cedar | `5af7b8cd78e4e0da3ae23f1715023fff8e62941d` | Authorize a permitted request | A matching forbid policy wins and denies |
| apache/opendal | `532050ac3c099dd8591cde652a8ed1aaf03ba418` | Persist and read an audit object | Reading a missing audit object returns `NotFound` |

The paths in `Cargo.toml` are intentionally local exact-revision probe bindings. The final product uses immutable Git revisions and independently proves the runtime call sites.
