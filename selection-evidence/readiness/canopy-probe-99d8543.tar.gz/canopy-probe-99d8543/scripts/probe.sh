#!/usr/bin/env bash
set -euo pipefail

ROOT="${UPSTREAM_ROOT:?set UPSTREAM_ROOT to the exact-revision upstream clone root}"
TARGET="${CARGO_TARGET_DIR:?set CARGO_TARGET_DIR outside the source checkout}"
export CARGO_TARGET_DIR="$TARGET"

run_test() {
  local manifest="$1" package="$2" test_name="$3"
  local output
  output="$(cargo test --manifest-path "$manifest" -p "$package" "$test_name" -- --nocapture 2>&1)"
  printf '%s\n' "$output"
  grep -Eq 'test result: ok\. [1-9][0-9]* passed' <<<"$output"
}

case "${1:-}" in
  rucelium-success)
    run_test "$ROOT/rucelium/Cargo.toml" rucelium-ingest \
      tests::happy_path_ingests_verified_sample_with_registry_firmware
    ;;
  rucelium-failure)
    run_test "$ROOT/rucelium/Cargo.toml" rucelium-ingest \
      tests::forged_packets_do_not_advance_the_replay_window
    ;;
  worldgraph-success)
    run_test "$ROOT/worldgraph/Cargo.toml" wifi-densepose-worldgraph \
      graph::tests::semantic_state_provenance_and_contradiction
    ;;
  worldgraph-failure)
    run_test "$ROOT/worldgraph/Cargo.toml" wifi-densepose-worldgraph \
      graph::tests::add_edge_unknown_endpoint_errors
    ;;
  midstream-success|midstream-failure|opendal-success|opendal-failure)
    cargo run --locked --quiet -- "${1}"
    ;;
  latentmesh-success)
    run_test "$ROOT/latentmesh/Cargo.toml" latentmesh-air-core \
      fragment::tests::reassembles_out_of_order_and_ignores_exact_duplicate
    ;;
  latentmesh-failure)
    run_test "$ROOT/latentmesh/Cargo.toml" latentmesh-air-core \
      fragment::tests::rejects_conflicting_duplicate
    ;;
  ruv-fann-success)
    run_test "$ROOT/ruv-fann/Cargo.toml" ruv-fann \
      tests::network_tests::test_deterministic_forward_pass
    ;;
  ruv-fann-failure)
    run_test "$ROOT/ruv-fann/Cargo.toml" ruv-fann \
      tests::network_tests::test_network_run_rejects_wrong_input_size
    ;;
  cedar-success)
    run_test "$ROOT/cedar/Cargo.toml" cedar-policy \
      ffi::is_authorized::test::test_authorized_on_simple_slice
    ;;
  cedar-failure)
    run_test "$ROOT/cedar/Cargo.toml" cedar-policy \
      ffi::is_authorized::test::test_authorized_on_multi_policy_slice_denies_when_expected
    ;;
  *)
    printf 'unsupported readiness probe: %s\n' "${1:-<missing>}" >&2
    exit 64
    ;;
esac
