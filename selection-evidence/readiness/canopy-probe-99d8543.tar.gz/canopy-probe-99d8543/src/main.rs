use midstreamer_temporal_compare::{ComparisonAlgorithm, Sequence, TemporalComparator, TemporalError};
use opendal::{Operator, services::Memory};

fn midstream_success() {
    let comparator = TemporalComparator::new(8, 32);
    let mut left = Sequence::new();
    let mut right = Sequence::new();
    for (timestamp, value) in [1.0_f64, 2.0, 3.0].into_iter().enumerate() {
        left.push(value, timestamp as u64);
    }
    for (timestamp, value) in [1.0_f64, 2.1, 3.0].into_iter().enumerate() {
        right.push(value, timestamp as u64);
    }
    let result = comparator
        .compare(&left, &right, ComparisonAlgorithm::DTW)
        .expect("DTW comparison must execute");
    assert!(result.distance.is_finite());
    println!("midstream success distance={}", result.distance);
}

fn midstream_failure() {
    let comparator = TemporalComparator::new(8, 2);
    let mut oversized = Sequence::new();
    let mut baseline = Sequence::new();
    for (timestamp, value) in [1_i64, 2, 3].into_iter().enumerate() {
        oversized.push(value, timestamp as u64);
    }
    for (timestamp, value) in [1_i64, 2].into_iter().enumerate() {
        baseline.push(value, timestamp as u64);
    }
    let error = comparator
        .compare(&oversized, &baseline, ComparisonAlgorithm::LCS)
        .expect_err("oversized temporal sequence must fail");
    assert!(matches!(error, TemporalError::SequenceTooLong(3)));
    println!("midstream failure asserted={error}");
}

async fn opendal_success() {
    let operator = Operator::new(Memory::default()).expect("memory builder");
    operator
        .write("audit/site-17/observation.json", br#"{"health":"stable"}"#.to_vec())
        .await
        .expect("audit write");
    let bytes = operator
        .read("audit/site-17/observation.json")
        .await
        .expect("audit read");
    assert_eq!(bytes.to_vec(), br#"{"health":"stable"}"#);
    println!("opendal success persisted_bytes={}", bytes.len());
}

async fn opendal_failure() {
    let operator = Operator::new(Memory::default()).expect("memory builder");
    let error = operator
        .read("audit/missing.json")
        .await
        .expect_err("missing audit object must fail");
    assert_eq!(error.kind(), opendal::ErrorKind::NotFound);
    println!("opendal failure asserted_kind={:?}", error.kind());
}

#[tokio::main]
async fn main() {
    match std::env::args().nth(1).as_deref() {
        Some("midstream-success") => midstream_success(),
        Some("midstream-failure") => midstream_failure(),
        Some("opendal-success") => opendal_success().await,
        Some("opendal-failure") => opendal_failure().await,
        _ => panic!("expected a supported readiness probe mode"),
    }
}

